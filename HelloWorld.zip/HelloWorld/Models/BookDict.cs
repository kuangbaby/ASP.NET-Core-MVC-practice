﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Models
{
    [Table("book_dict")]
    public class BookDict
    {
        public int Id { get; set; }
        [Column("dict_code")]

        public string DictCode
        {
            get;
            set;
        }
        [Column("dict_name")]

        public string DictName
        {
            get;
            set;
        }

    }
}
