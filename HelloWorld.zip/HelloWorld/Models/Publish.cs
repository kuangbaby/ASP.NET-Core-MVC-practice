﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace HelloWorld.Models
{
    [Table("publish")]
    public class Publish
    {
        public int Id
        {
            get;
            set;
        }
        [Column("p_ISBN")]
        public string PISBN
        {
            get;
            set;
        }
        [Column("p_name")]
        public string Pname
        {
            get;
            set;
        }
    }
}