﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Models
{
    [Table("book_status")]
    public class State
    {
        public int Id { get; set; }
        [Column("status_code")]
        public string StateCode { get; set; }

        [Column("status_name")]
        public string StateName { get; set; }

    }
}
