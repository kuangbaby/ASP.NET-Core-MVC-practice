﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace HelloWorld.Models
{
    [Table("book")]
    public class BookDetail
    {
        public int Id { get; set; }
        [Column("p_ISBN")]
        public string PublishISBN { get; set; }
        [Column("b_name")]
        public string BookName { get; set; }
        [Column("author")]
        public string Author { get; set; }
        [Column("dict_code")]
        public string DictCode { get; set; }
        [Column("book_ISBN")]
        public string BookISBN { get; set; }
        [Column("page")]
        public int Page { get; set; }
        [Column("p_time")]
        public DateTime? Time { get; set; }
        [Column("copy")]
        public int Copy { get; set; }
        [Column("b_number")]
        public int BookNumber { get; set; }
        [Column("b_count")]
        public int BookCount { get; set; }
    }
    /*public class BookViewModel
    {
        public List<BookDetailViewModel> BookDetails { get;set; }
        public SelectList BookDicts { get; set; }
    }
    public class BookDetailViewModel : BookDetail
    {
        public BookDetailViewModel(BookDetail bookDetail)
        {
            //TODO bookdetailviewmodel property = bookdetail property
            public string Author { get; internal set; }
            public string BookDicts { get; internal set; }
            public string Place { get; internal set; }
            public string DictName { get; internal set; }
        }
    }*/
}
