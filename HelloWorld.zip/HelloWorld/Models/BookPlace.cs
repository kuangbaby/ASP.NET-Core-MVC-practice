﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Models
{
    [Table("book_place")]
    public class BookPlace
    {
        public int Id { get; set; }
        [Column("place_code")]
        public string PlaceCode
        {
            get; set;
        }
        [Column("place")]
        public string Place
        {
            get; set;
        }
    }
}