﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HelloWorld.Models;

namespace HelloWorld.Data
{
    public class HelloWorldContext : DbContext
    {
        public HelloWorldContext (DbContextOptions<HelloWorldContext> options)
            : base(options)
        {
        }
        
        public DbSet<HelloWorld.Models.BookDict> BookDict { get; set; }
        public DbSet<HelloWorld.Models.BookPlace> BookPlace { get; set; }
        public DbSet<HelloWorld.Models.State> State { get; set; }
        public DbSet<HelloWorld.Models.Publish> Publish { get; set; }
        public DbSet<HelloWorld.Models.BookDetail> BookDetail { get; set; }
    }
}
