﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HelloWorld.Data;
using HelloWorld.Models;

namespace HelloWorld.Controllers
{
    public class BookDetailsController : Controller
    {
        private readonly HelloWorldContext _context;

        public BookDetailsController(HelloWorldContext context)
        {
            _context = context;
        }

        // GET: BookDetails
        public async Task<IActionResult> Index()
        {
            /*var bookDict = await _context.BookDict.ToListAsync();
            var bookDetailViewModel = _context.BookDetail.Join(_context.BookDict,book => book.DictCode,bookDict => bookDict.DictCode,
                (book,bookDict)=> new BookDetailViewModel(book) { 
                    DictName = bookDict.DictName,
                });
            var bookViewModel = new BookViewModel
            {
                BookDetails = bookDetailViewModel.ToList(),
                BookDicts = new SelectList(bookDict),
            };
            return View(bookViewModel);*/
            return View(await _context.BookDetail.ToListAsync());
        }

        // GET: BookDetails/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookDetail = await _context.BookDetail
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bookDetail == null)
            {
                return NotFound();
            }

            return View(bookDetail);
        }

        // GET: BookDetails/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: BookDetails/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,PublishISBN,BookName,Author,DictCode,BookISBN,Page,Time,Copy,BookNumber,BookCount")] BookDetail bookDetail)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bookDetail);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(bookDetail);
        }

        // GET: BookDetails/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookDetail = await _context.BookDetail.FindAsync(id);
            if (bookDetail == null)
            {
                return NotFound();
            }
            return View(bookDetail);
        }

        // POST: BookDetails/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,PublishISBN,BookName,Author,DictCode,BookISBN,Page,Time,Copy,BookNumber,BookCount")] BookDetail bookDetail)
        {
            if (id != bookDetail.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bookDetail);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookDetailExists(bookDetail.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(bookDetail);
        }

        // GET: BookDetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookDetail = await _context.BookDetail
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bookDetail == null)
            {
                return NotFound();
            }

            return View(bookDetail);
        }

        // POST: BookDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bookDetail = await _context.BookDetail.FindAsync(id);
            _context.BookDetail.Remove(bookDetail);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookDetailExists(int id)
        {
            return _context.BookDetail.Any(e => e.Id == id);
        }
    }
}
