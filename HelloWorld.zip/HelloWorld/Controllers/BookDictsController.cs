﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HelloWorld.Data;
using HelloWorld.Models;

namespace HelloWorld.Controllers
{
    public class BookDictsController : Controller
    {
        private readonly HelloWorldContext _context;

        public BookDictsController(HelloWorldContext context)
        {
            _context = context;
        }

        // GET: BookDicts
        public async Task<IActionResult> Index()
        {
            return View(await _context.BookDict.ToListAsync());
        }

        // GET: BookDicts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookDict = await _context.BookDict
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bookDict == null)
            {
                return NotFound();
            }

            return View(bookDict);
        }

        // GET: BookDicts/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: BookDicts/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,DictCode,DictName")] BookDict bookDict)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bookDict);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(bookDict);
        }

        // GET: BookDicts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookDict = await _context.BookDict.FindAsync(id);
            if (bookDict == null)
            {
                return NotFound();
            }
            return View(bookDict);
        }

        // POST: BookDicts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,DictCode,DictName")] BookDict bookDict)
        {
            if (id != bookDict.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bookDict);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookDictExists(bookDict.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(bookDict);
        }

        // GET: BookDicts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookDict = await _context.BookDict
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bookDict == null)
            {
                return NotFound();
            }

            return View(bookDict);
        }

        // POST: BookDicts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bookDict = await _context.BookDict.FindAsync(id);
            _context.BookDict.Remove(bookDict);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookDictExists(int id)
        {
            return _context.BookDict.Any(e => e.Id == id);
        }
    }
}
