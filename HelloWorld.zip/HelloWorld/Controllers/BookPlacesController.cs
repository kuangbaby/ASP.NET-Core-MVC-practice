﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HelloWorld.Data;
using HelloWorld.Models;

namespace HelloWorld.Controllers
{
    public class BookPlacesController : Controller
    {
        private readonly HelloWorldContext _context;

        public BookPlacesController(HelloWorldContext context)
        {
            _context = context;
        }

        // GET: BookPlaces
        public async Task<IActionResult> Index()
        {
            return View(await _context.BookPlace.ToListAsync());
        }

        // GET: BookPlaces/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookPlace = await _context.BookPlace
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bookPlace == null)
            {
                return NotFound();
            }

            return View(bookPlace);
        }

        // GET: BookPlaces/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: BookPlaces/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,PlaceCode,Place")] BookPlace bookPlace)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bookPlace);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(bookPlace);
        }

        // GET: BookPlaces/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookPlace = await _context.BookPlace.FindAsync(id);
            if (bookPlace == null)
            {
                return NotFound();
            }
            return View(bookPlace);
        }

        // POST: BookPlaces/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,PlaceCode,Place")] BookPlace bookPlace)
        {
            if (id != bookPlace.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bookPlace);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookPlaceExists(bookPlace.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(bookPlace);
        }

        // GET: BookPlaces/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bookPlace = await _context.BookPlace
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bookPlace == null)
            {
                return NotFound();
            }

            return View(bookPlace);
        }

        // POST: BookPlaces/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bookPlace = await _context.BookPlace.FindAsync(id);
            _context.BookPlace.Remove(bookPlace);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookPlaceExists(int id)
        {
            return _context.BookPlace.Any(e => e.Id == id);
        }
    }
}
